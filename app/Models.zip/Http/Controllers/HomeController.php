<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;

class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
     
        $order = Order::where("status", "Order")->count();
        $challan = Order::where("status", "Challan")->count();
        return response()->json(['status' => 200, "message" => "Order list", "data" => [
            "order" => $order,
            "challan" => $challan,
            "totalPyment" => 1000,
            "pendingPayment" => "100"
        ]]);
    }

   
}
