<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $product = Category::with("products")->get();
        return response()->json(['status' => 200, "message" => "Product list", "data" => $product]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'title' => 'required|string',
            'price' => 'required|string',
            'is_dynamic' => 'required|string',
        ]);
        if ($validator->fails()) {
            return response()->json(['statusCode' => 403, 'message' => 'Validation Error', 'data' => $validator->errors()]);
        }

        $product = new Product();
        $product->title = $request->get("title");
        $product->price = $request->get("price");
        $product->is_dynamic = $request->get("is_dynamic");
        $product->save();

        return response()->json(['statusCode' => 201, 'message' => 'Product inserted successfully', 'data' => $product]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $product = Product::find($id);
        if ($product) {
            return response()->json(['statusCode' => 200, 'message' => 'Product details', 'data' => $product]);
        } else {
            return response()->json(['statusCode' => 404, 'message' => 'Product not found', 'data' => []]);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'title' => 'required|string',
            'price' => 'required|string',
            'is_dynamic' => 'required|string',
        ]);
        if ($validator->fails()) {
            return response()->json(['statusCode' => 403, 'message' => 'Validation Error', 'data' => $validator->errors()]);
        }

        $product = Product::find($id);
        if ($product) {
            $product->title = $request->get("title");
            $product->price = $request->get("price");
            $product->is_dynamic = $request->get("is_dynamic");
            $product->update();
            return response()->json(['statusCode' => 201, 'message' => 'Product updated successfully', 'data' => $product]);
        }
        return response()->json(['statusCode' => 404, 'message' => 'Product not found', 'data' => []]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $product = Product::find($id);

        if ($product) {
            $product->delete();
            return response()->json(['statusCode' => 200, 'message' => 'Product deleted successfully', 'data' => $product]);
        } else {
            return response()->json(['statusCode' => 404, 'message' => 'Product not found', 'data' => []]);
        }
    }
}
