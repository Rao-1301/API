<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Order;
use App\Models\Site;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CustomerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $customer = Customer::with("sites")->get();
        return response()->json(['status' => 200, "message" => "Customer list", "data" => $customer]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'name' => 'required|string',
            'mobile' => 'required|string',
            'address' => 'required|string',
        ]);
        if ($validator->fails()) {
            return response()->json(['statusCode' => 403, 'message' => 'Validation Error', 'data' => $validator->errors()]);
        }

        $customer = new Customer();
        $customer->name = $request->get("name");
        $customer->mobile = $request->get("mobile");
        $customer->address = $request->get("address");
        $customer->save();
        
        $sites = $request->get("sites");
        if($sites){
            foreach($sites as $site) {
                $siten = new Site();
                if(isset($site["id"]) && $site["id"]){
                    $siten = Site::find($site["id"]);
                }
                $siten->title = $site['title'];
                $siten->customer_id = $customer->id;
                $siten->save();
            }
        }

        return response()->json(['statusCode' => 201, 'message' => 'Customer inserted successfully', 'data' => $customer]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $customer = Customer::find($id);

        if ($customer) {
            return response()->json(['statusCode' => 200, 'message' => 'Customer details', 'data' => $customer]);
        } else {
            return response()->json(['statusCode' => 404, 'message' => 'Customer not found', 'data' => []]);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string',
            'mobile' => 'required|string',
            'address' => 'required|string'
        ]);
        if ($validator->fails()) {
            return response()->json(['statusCode' => 403, 'message' => 'Validation Error', 'data' => $validator->errors()]);
        }

        $customer = Customer::find($id);
        if ($customer) {
            $customer->name = $request->get("name");
            $customer->mobile = $request->get("mobile");
            $customer->address = $request->get("address");
            $customer->update();
            
            $ids = [];
            $sites = $request->get("sites");
            if($sites){
                foreach($sites as $site) {
                    $siten = new Site();
                    if(isset($site["id"]) && $site["id"]){
                        $siten = Site::find($site["id"]);
                    }
                    $siten->title = $site['title'];
                    $siten->customer_id = $customer->id;
                    $siten->save();
                    $ids[] = $siten->id;
                }
            }
            Site::where("customer_id",  $customer->id)->whereNotIn('id', $ids)->delete();

            return response()->json(['statusCode' => 201, 'message' => 'Customer updated successfully', 'data' => $customer]);
        }
        return response()->json(['statusCode' => 404, 'message' => 'Customer not found', 'data' => []]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $customer = Customer::find($id);

        if ($customer) {
            $customer->delete();
            return response()->json(['statusCode' => 200, 'message' => 'Customer deleted successfully', 'data' => $customer]);
        } else {
            return response()->json(['statusCode' => 404, 'message' => 'Customer not ound', 'data' => []]);
        }
    }
    public function orders($id){
        $order = Order::with(["customer", "site", "user"])->where("customer_id", $id)->orderBy("id", "desc")->paginate(50);
        return response()->json(['status' => 200, "message" => "Order list", "data" => $order]);
    }
}
