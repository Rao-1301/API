<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $order = Order::with(["customer", "site", "user"])->where("status", "Order")->orderBy("id", "desc")->paginate(50);
        return response()->json(['status' => 200, "message" => "Order list", "data" => $order]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function challan()
    {
        $order = Order::with("customer", "site", "user")->where("status", "Challan")->orderBy("id", "desc")->paginate(50);
        return response()->json(['status' => 200, "message" => "Order list", "data" => $order]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'customer_id' => 'required',
            'site_id' => 'required',
            'vehicle_no' => 'required',
            'total' => 'required',
            'status' => 'required',
            "order_items" => "required",
            "order_items.*.product_id" => "required",
            "order_items.*.product_name" => "required",
            "order_items.*.size" => "required",
            "order_items.*.nos" => "required",
            "order_items.*.unit" => "required",
            "order_items.*.qty" => "required",
            "order_items.*.price" => "required_if:status,Order",
            "order_items.*.total_price" => "required_if:status,Order",
        ]);
        if ($validator->fails()) {
            return response()->json(['statusCode' => 403, 'message' => 'Validation Error', 'data' => $validator->errors()]);
        }

        try {
            DB::beginTransaction();

            $order = new Order();
            $order->customer_id = $request->get("customer_id");
            $order->site_id = $request->get("site_id");
            $order->vehicle_no = $request->get("vehicle_no");
            $order->total = $request->get("total");
            $order->status = $request->get("status");
            $order->user_id = Auth::user()->id;
            $order->save();


            foreach ($request->get("order_items") as $ord) {
                $orderItem = new OrderItem();
                $orderItem->order_id = $order->id;
                $orderItem->product_id = $ord["product_id"];
                $orderItem->product_name = $ord["product_name"];
                $orderItem->size = $ord["size"];
                $orderItem->description = "";
                $orderItem->nos = $ord["nos"];
                $orderItem->unit = $ord["unit"];
                $orderItem->qty = $ord["qty"];
                $orderItem->price = $ord["price"];
                $orderItem->total_price = $ord["total_price"];
                $orderItem->discount = "";
                $orderItem->save();

                if ((isset($ord["price"]) && $ord["price"])) {
                    $product = Product::find($ord["product_id"]);
                    if ($product) {
                        $product->unit = $ord["unit"];
                        $product->price = $ord["price"];
                        $product->save();
                    }
                }
            }

            DB::commit();

            return response()->json(['statusCode' => 201, 'message' => 'Order created successfully', 'data' => $order]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['statusCode' => 400, 'message' => 'Order create request Fail;', 'data' => $e->getMessage()]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $order = Order::with(["orderItems", "orderItems.product", "customer", "site", "user"])->find($id);
        if ($order) {
            return response()->json(['statusCode' => 200, 'message' => 'Order details', 'data' => $order]);
        } else {
            return response()->json(['statusCode' => 404, 'message' => 'Order not found', 'data' => []]);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'customer_id' => 'required',
            'site_id' => 'required',
            'vehicle_no' => 'required',
            'total' => 'required',
            'status' => 'required',
            "order_items" => "required",
            "order_items.*.product_id" => "required",
            "order_items.*.product_name" => "required",
            "order_items.*.size" => "required",
            "order_items.*.nos" => "required",
            "order_items.*.unit" => "required",
            "order_items.*.qty" => "required",
            "order_items.*.price" => "required_if:status,Order",
            "order_items.*.total_price" => "required_if:status,Order",
        ]);
        if ($validator->fails()) {
            return response()->json(['statusCode' => 403, 'message' => 'Validation Error', 'data' => $validator->errors()]);
        }

        try {
            DB::beginTransaction();
            $order = Order::find($id);
            if ($order) {
                $order->customer_id = $request->get("customer_id");
                $order->site_id = $request->get("site_id");
                $order->vehicle_no = $request->get("vehicle_no");
                $order->total = $request->get("total");
                $order->status = $request->get("status");
                $order->save();

                OrderItem::destroy($request->get("deleted_items"));

                foreach ($request->get("order_items") as $ord) {
                    $orderItem = OrderItem::find($ord["id"]);
                    if (!$orderItem) {
                        $orderItem = new OrderItem();
                        $orderItem->order_id = $order->id;
                    }
                    $orderItem->product_id = $ord["product_id"];
                    $orderItem->product_name = $ord["product_name"];
                    $orderItem->size = $ord["size"];
                    $orderItem->description = "";
                    $orderItem->nos = $ord["nos"];
                    $orderItem->unit = $ord["unit"];
                    $orderItem->qty = $ord["qty"];
                    $orderItem->price = $ord["price"];
                    $orderItem->total_price = $ord["total_price"];
                    $orderItem->discount = "";
                    $orderItem->save();
                    
                    if ((isset($ord["price"]) && $ord["price"])) {
                        $product = Product::find($ord["product_id"]);
                        if ($product) {
                            $product->unit = $ord["unit"];
                            $product->price = $ord["price"];
                            $product->save();
                        }
                    }
                }
            }

            DB::commit();
            $order = Order::with(["orderItems", "orderItems.product", "customer", "site"])->find($id);
            return response()->json(['statusCode' => 201, 'message' => 'Order updated successfully', 'data' => $order]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['statusCode' => 400, 'message' => 'Order update request Fail;', 'data' => $e->getMessage()]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $order = Order::find($id);

        if ($order) {
            $order->delete();
            return response()->json(['statusCode' => 200, 'message' => 'Order deleted successfully', 'data' => $order]);
        } else {
            return response()->json(['statusCode' => 404, 'message' => 'Order not found', 'data' => []]);
        }
    }

    public function challanDelete($id)
    {
        $order = Order::where(["status" => "Challan", 'id' => $id])->delete();
        return response()->json(['status' => 200, "message" => "Clallan Delete Successfully", "data" => $order]);
    }
}
