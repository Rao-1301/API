<?php

namespace App\Http\Controllers;

use App\Models\OrderItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class OrderItemController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $orderItem = OrderItem::all();
        return response()->json(['status' => 200, "message" => "Order item list", "data" => $orderItem]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'title' => 'required|string',
            'price' => 'required|string',
            'is_dynamic' => 'required|string',
        ]);
        if ($validator->fails()) {
            return response()->json(['statusCode' => 403, 'message' => 'Validation Error', 'data' => $validator->errors()]);
        }

        $orderItem = new OrderItem();
        $orderItem->order_id = $request->get("order_id");
        $orderItem->product_name = $request->get("product_name");
        $orderItem->description = $request->get("description");
        $orderItem->size = $request->get("size");
        $orderItem->nos = $request->get("nos");
        $orderItem->unit = $request->get("unit");
        $orderItem->qty = $request->get("qty");
        $orderItem->price = $request->get("price");
        $orderItem->descount = $request->get("descount");
        $orderItem->total_price = $request->get("total_price");
        $orderItem->save();

        return response()->json(['statusCode' => 201, 'message' => 'Order item created successfully', 'data' => $orderItem]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $orderItem = OrderItem::find($id);
        if ($orderItem) {
            return response()->json(['statusCode' => 200, 'message' => 'Order item details', 'data' => $orderItem]);
        } else {
            return response()->json(['statusCode' => 404, 'message' => 'Order item not found', 'data' => []]);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'title' => 'required|string',
            'price' => 'required|string',
            'is_dynamic' => 'required|string',
        ]);
        if ($validator->fails()) {
            return response()->json(['statusCode' => 403, 'message' => 'Validation Error', 'data' => $validator->errors()]);
        }

        $orderItem = OrderItem::find($id);
        if ($orderItem) {
            $orderItem->product_name = $request->get("product_name");
            $orderItem->description = $request->get("description");
            $orderItem->size = $request->get("size");
            $orderItem->nos = $request->get("nos");
            $orderItem->unit = $request->get("unit");
            $orderItem->qty = $request->get("qty");
            $orderItem->price = $request->get("price");
            $orderItem->descount = $request->get("descount");
            $orderItem->total_price = $request->get("total_price");
            $orderItem->update();
            return response()->json(['statusCode' => 201, 'message' => 'Order item updated successfully', 'data' => $orderItem]);
        }
        return response()->json(['statusCode' => 404, 'message' => 'Order item not found', 'data' => []]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $orderItem = OrderItem::find($id);

        if ($orderItem) {
            $orderItem->delete();
            return response()->json(['statusCode' => 200, 'message' => 'Order item deleted successfully', 'data' => $orderItem]);
        } else {
            return response()->json(['statusCode' => 404, 'message' => 'Order item not found', 'data' => []]);
        }
    }
}
